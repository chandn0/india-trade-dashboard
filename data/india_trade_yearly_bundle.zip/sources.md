Official sources used

- Exports: https://tradestat.commerce.gov.in/eidb/commodity_wise_export
- Imports: https://tradestat.commerce.gov.in/eidb/commodity_wise_import
- TRADESTAT landing page: https://tradestat.commerce.gov.in/

Notes
- The TRADESTAT page shows data available from 2017-2018 to 2025-2026.
- The year dropdown on the export/import commodity-wise pages starts at 2018-2019, so 2017-2018 was reconstructed from the prior-year comparison shown in the 2018-2019 selection.
- 2025-2026 is year-to-date, not a completed financial year.
- Values are in US $ Million.
